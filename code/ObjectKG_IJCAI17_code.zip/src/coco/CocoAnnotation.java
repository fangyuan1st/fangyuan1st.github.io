package coco;

public class CocoAnnotation {
	public int id;
	public int imageId;
	public int categoryId;
	public double area;
	
	public double x;
	public double y;
	public double width;
	public double height;
	
	public boolean iscrowd;
	
	public CocoAnnotation(int id, int imageId, int categoryId, double area, double x, double y, double width, double height, boolean iscrowd) {
        this.id = id;
		this.imageId = imageId;
        this.categoryId = categoryId;
        this.area = area;
		
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		
		this.iscrowd = iscrowd;
    }
    
    public CocoAnnotation(CocoAnnotation cocoAnnotation) {
    	this(cocoAnnotation.id, cocoAnnotation.imageId, cocoAnnotation.categoryId, cocoAnnotation.area, cocoAnnotation.x, cocoAnnotation.y, cocoAnnotation.width, cocoAnnotation.height, cocoAnnotation.iscrowd);
    }
}