package coco;
import java.io.FileReader;
import java.io.FileNotFoundException;

import javax.json.Json;
import javax.json.JsonReader;
import javax.json.JsonStructure;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonValue;

import gnu.trove.map.hash.THashMap;


public class CocoGroundtruths extends Groundtruths {
	
	@Override
	public boolean read(String filePath) {
		imageMap = new THashMap<Integer, ImageGroundtruth>();
		
		try {
			JsonReader reader = Json.createReader(new FileReader(filePath));
			JsonStructure jsonst = reader.read();
			
			JsonArray images = ((JsonObject) jsonst).getJsonArray("images");
			
			for (JsonValue imageValue : images) {
				JsonObject image = (JsonObject) imageValue;
				
				int imageId = image.getInt("id");
				int width = image.getInt("width");
				int height = image.getInt("height");
				
				imageMap.put(imageId, new ImageGroundtruth(imageId, width, height));
			}
			
			JsonArray annotations = ((JsonObject) jsonst).getJsonArray("annotations");
			
			for (JsonValue annotationValue : annotations) {
				JsonObject annotation = (JsonObject) annotationValue;
				
				int id = annotation.getInt("id");
				int imageId = annotation.getInt("image_id");
				int categoryId = annotation.getInt("category_id");
				double area = annotation.getJsonNumber("area").doubleValue();
				
				JsonArray bbox = annotation.getJsonArray("bbox");
				double x = bbox.getJsonNumber(0).doubleValue();
				double y = bbox.getJsonNumber(1).doubleValue();
				double width = bbox.getJsonNumber(2).doubleValue();
				double height = bbox.getJsonNumber(3).doubleValue();
				
				boolean iscrowd = false;
				if (annotation.getInt("iscrowd") == 1)
					iscrowd = true;
				
				CocoAnnotation cocoAnnotation = new CocoAnnotation(id, imageId, categoryId, area, x, y, width, height, iscrowd);
				
				imageMap.get(imageId).annotations.add(cocoAnnotation);
			}
			
			System.out.println("Finished loading groundtruths JSON file");
            return true;
		}
		catch (FileNotFoundException ex) {
            System.out.println("Could not load groundtruths JSON file");
            return false;
        }
	}
}