package coco;
import gnu.trove.map.hash.THashMap;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.json.Json;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonGenerator;

import java.util.Map;


//class to read and write COCO image detection results
public class CocoResults extends Results {
	
    
    //reads results from JSON file
	@Override
    public boolean read(String filePath) {
        imageMap = new THashMap<Integer, ImageResult>();

        try {
            //create JSON parser that will read file
            JsonParser parser = Json.createParser(new FileReader(filePath));
            System.out.println("Loading JSON file...");
            
            //attributes to read
            int imageId = 0;
            int categoryId = 0;
            double[] bbox = new double[4];
            double score = 0;
            
            //keep count of how many attributes have been read for this detection
            int count = 0;
            
            // keep track of total num of detections read in so far
            int ndets = 0;
            
            //read through entire file
            while (parser.hasNext()) {
                JsonParser.Event event = parser.next();
                
                //if current item is a key
                if (event == JsonParser.Event.KEY_NAME) {
                    //read value depending on the key name
                    switch(parser.getString()) {
                        case "image_id":
                            parser.next();
                            imageId = parser.getInt();
                            count++;
                            break;
                        case "category_id":
                            parser.next();
                            categoryId = parser.getInt();
                            count++;
                            break;
                        case "bbox":
                            parser.next();
                            bbox = new double[4];
                            for (int i = 0; i < 4; i++) {
                                parser.next();
                                bbox[i] = parser.getBigDecimal().doubleValue();
                            }
                            count++;
                            break;
                        case "score":
                            parser.next();
                            score = parser.getBigDecimal().doubleValue();
                            count++;
                            break;
                    }
                }
                
                //once all 4 attributes have been read for one detection
                if (count == 4) {
                    count = 0;

                    //create detection object
                    CocoDetection cocoDetection = new CocoDetection(imageId, categoryId, bbox, score);
                    ndets ++;
                    if (ndets % 1000000 == 0) 
                    	System.out.println(ndets / 1000000 + "M detections read ...");
                    
                    //store it in corresponding image result depending on image id
                    if (imageMap.containsKey(imageId)) {
                        imageMap.get(imageId).detections.add(cocoDetection);
                    }
                    else {
                        imageMap.put(imageId, new ImageResult(imageId));
                        imageMap.get(imageId).detections.add(cocoDetection);
                    }
                }
            }

            System.out.println("Finished loading JSON file");
            return true;
        }
        catch (FileNotFoundException ex) {
            System.out.println("Could not load JSON file");
            return false;
        }
    }

    //write results to JSON file
	@Override
    public boolean write(String filePath) {
        try {
            //create JSON generator that will write to file
            JsonGenerator generator = Json.createGenerator(new FileWriter(filePath));
            System.out.println("Writing JSON file...");

            generator.writeStartArray();

            //for each image in the hashmap
            for (Map.Entry<Integer, ImageResult> entry : imageMap.entrySet()) {
                //for each detection in the image
                for (CocoDetection cocoDetection : entry.getValue().detections) {
                    //write detection attributes
                    generator.writeStartObject();
                    generator.write("image_id", cocoDetection.imageId);
                    generator.write("category_id", cocoDetection.categoryId);

                    generator.writeStartArray("bbox");
                    for (int i = 0; i < 4; i++) {
                        generator.write(cocoDetection.bbox[i]);
                    }
                    generator.writeEnd();

                    generator.write("score", cocoDetection.score);
                    generator.writeEnd();
                }
            }

            generator.writeEnd();
            generator.close();

            System.out.println("Finished writing JSON file");
            return true;
        }
        catch (IOException ex) {
            System.out.println("Could not write JSON file");
            return false;
        }
    }
}
