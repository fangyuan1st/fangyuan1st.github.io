package coco;

import java.io.File;

import org.w3c.dom.*;

import gnu.trove.map.hash.THashMap;

import javax.xml.parsers.*;

import java.util.Map;
import java.util.HashMap;

public class VocGroundtruths extends Groundtruths {
    
    private Map<String, Integer> categoryNameToId;
   
    public VocGroundtruths() {
        //map voc category names to coco ids
        categoryNameToId = new THashMap<String, Integer>();
        categoryNameToId.put("aeroplane", 5);
        categoryNameToId.put("bicycle", 2);
        categoryNameToId.put("bird", 16);
        categoryNameToId.put("boat", 9);
        categoryNameToId.put("bottle", 44);
        categoryNameToId.put("bus", 6);
        categoryNameToId.put("car", 3);
        categoryNameToId.put("cat", 17);
        categoryNameToId.put("chair", 62);
        categoryNameToId.put("sofa", 63);
        categoryNameToId.put("cow", 21);
        categoryNameToId.put("diningtable", 67);
        categoryNameToId.put("dog", 18);
        categoryNameToId.put("horse", 19);
        categoryNameToId.put("motorbike", 4);
        categoryNameToId.put("person", 1);
        categoryNameToId.put("pottedplant", 64);
        categoryNameToId.put("sheep", 20);
        categoryNameToId.put("train", 7);
        categoryNameToId.put("tvmonitor", 72);
    }
    
    @Override
    public boolean read(String resultsDirectory) {
        imageMap = new HashMap<Integer, ImageGroundtruth>();
        
        System.out.println("Loading VOC groundtruths...");
        
        File directory = new File(resultsDirectory);
        File[] annotationFiles = directory.listFiles();
        
        //read each annotation file
        for (File annotationFile : annotationFiles) {
            try {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                
                Document document = builder.parse(annotationFile);
                
                //get image information
                String filename = document.getElementsByTagName("filename").item(0).getTextContent();
                int imageId = Integer.parseInt(filename.substring(0, 6));
                int imageWidth = Integer.parseInt(document.getElementsByTagName("width").item(0).getTextContent());
                int imageHeight = Integer.parseInt(document.getElementsByTagName("height").item(0).getTextContent());
                
                imageMap.put(imageId, new ImageGroundtruth(imageId, imageWidth, imageHeight));
                
                NodeList objects = document.getElementsByTagName("object");
                
                //read each groundtruth
                for (int i = 0; i < objects.getLength(); i++) {
                    Element object = (Element) (objects.item(i));
                    
                    String categoryName = object.getElementsByTagName("name").item(0).getTextContent();
                    int categoryId = categoryNameToId.get(categoryName);
                    
                    int x = Integer.parseInt(object.getElementsByTagName("xmin").item(0).getTextContent());
                    int y = Integer.parseInt(object.getElementsByTagName("ymin").item(0).getTextContent());
                    int width = Integer.parseInt(object.getElementsByTagName("xmax").item(0).getTextContent()) - x;
                    int height = Integer.parseInt(object.getElementsByTagName("ymax").item(0).getTextContent()) - y;
                    
                    CocoAnnotation cocoAnnotation = new CocoAnnotation(0, imageId, categoryId, 0, x, y, width, height, false);
                    imageMap.get(imageId).annotations.add(cocoAnnotation);
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        
        System.out.println("Finished loading VOC groundtruths");
        return true;
    }
}