package coco;

import java.io.File;

import java.io.FileReader;
import java.io.BufferedReader;

import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;

import java.util.Map;

import gnu.trove.map.hash.THashMap;

import java.util.HashMap;

public class VocResults extends Results {
    private Map<String, Integer> categoryNameToId;
    
    public VocResults() {
        //map voc category names to coco ids
        categoryNameToId = new THashMap<String, Integer>();
        categoryNameToId.put("aeroplane", 5);
        categoryNameToId.put("bicycle", 2);
        categoryNameToId.put("bird", 16);
        categoryNameToId.put("boat", 9);
        categoryNameToId.put("bottle", 44);
        categoryNameToId.put("bus", 6);
        categoryNameToId.put("car", 3);
        categoryNameToId.put("cat", 17);
        categoryNameToId.put("chair", 62);
        categoryNameToId.put("sofa", 63);
        categoryNameToId.put("cow", 21);
        categoryNameToId.put("diningtable", 67);
        categoryNameToId.put("dog", 18);
        categoryNameToId.put("horse", 19);
        categoryNameToId.put("motorbike", 4);
        categoryNameToId.put("person", 1);
        categoryNameToId.put("pottedplant", 64);
        categoryNameToId.put("sheep", 20);
        categoryNameToId.put("train", 7);
        categoryNameToId.put("tvmonitor", 72);
    }
    
    @Override
    public boolean read(String resultsDirectory) {
        imageMap = new HashMap<Integer, ImageResult>();
        
        /** added to automatically pull out files from dir **/
        File[] files = new File(resultsDirectory).listFiles();
        
        //read results for each category
        for (String categoryName : categoryNameToId.keySet()) {
            FileReader fileReader = null;
            BufferedReader bufferedReader = null;
            
            try {
            	// look for category name in files
            	String filename = null;
            	for (File f : files)
            		if (f.isFile() && f.getName().toLowerCase().endsWith("_" + categoryName.toLowerCase() + ".txt")) {
            			filename = f.getAbsolutePath();
            			break;
            		}
            	
                //load category results file
                fileReader = new FileReader(filename);
                bufferedReader = new BufferedReader(fileReader);
                
                //get category coco id
                int categoryId = categoryNameToId.get(categoryName);
                
                System.out.println("Loading " + categoryName + " results file...");
                
                //load each line as a single detection
                String line;
                line = bufferedReader.readLine();
                while (line != null) {
                    String[] values = line.split(" ");
                    
                    int imageId = Integer.parseInt(values[0]);
                    double score = Double.parseDouble(values[1]);
                    
                    double[] bbox = new double[4];
                    bbox[0] = Double.parseDouble(values[2]);
                    bbox[1] = Double.parseDouble(values[3]);
                    bbox[2] = Double.parseDouble(values[4]) - bbox[0];
                    bbox[3] = Double.parseDouble(values[5]) - bbox[1];
                    
                    CocoDetection cocoDetection = new CocoDetection(imageId, categoryId, bbox, score);
                    
                    //store it in corresponding image result depending on image id
                    if (imageMap.containsKey(imageId)) {
                        imageMap.get(imageId).detections.add(cocoDetection);
                    }
                    else {
                        imageMap.put(imageId, new ImageResult(imageId));
                        imageMap.get(imageId).detections.add(cocoDetection);
                    }
                    
                    line = bufferedReader.readLine();
                }
            }
            catch (IOException e) {
                e.printStackTrace();
                return false;
            }
            finally {
                try {
                    if (bufferedReader != null)
                        bufferedReader.close();
                    
                    if (fileReader != null)
                        fileReader.close();
                }
                catch (IOException ex) {
                    ex.printStackTrace();
                    return false;
                }
            }
        }
        
        System.out.println("Finished loading VOC results");
        
        return true;
    }
    
    
    
    @Override
    public boolean write(String resultsDirectory) {
        //create output directory
        File directory = new File(resultsDirectory);
        if (!directory.exists())
            directory.mkdirs();
        
        //write results for each category
        for (Map.Entry<String, Integer> entry : categoryNameToId.entrySet()) {
            String categoryName = entry.getKey();
            int categoryId = entry.getValue();
            
            BufferedWriter bufferedWriter = null;
            FileWriter fileWriter = null;
            
            try {
                //open category results file to write to
                fileWriter = new FileWriter(resultsDirectory + "/comp4_det_test_" + categoryName + ".txt");
                bufferedWriter = new BufferedWriter(fileWriter);
                
                System.out.println("Writing " + categoryName + " results file...");
                
                for (Map.Entry<Integer, ImageResult> imageEntry : imageMap.entrySet()) {
                    ImageResult imageResult = imageEntry.getValue();
                    
                    //write each detection as one line
                    for (CocoDetection cocoDetection : imageResult.detections) {
                        if (cocoDetection.categoryId == categoryId) {
                            bufferedWriter.write(String.format("%06d", cocoDetection.imageId) + " ");
                            bufferedWriter.write(Double.toString(cocoDetection.score) + " ");
                            bufferedWriter.write(Double.toString(cocoDetection.bbox[0]) + " ");
                            bufferedWriter.write(Double.toString(cocoDetection.bbox[1]) + " ");
                            bufferedWriter.write(Double.toString(cocoDetection.bbox[2] + cocoDetection.bbox[0]) + " ");
                            bufferedWriter.write(Double.toString(cocoDetection.bbox[3] + cocoDetection.bbox[1]));
                            bufferedWriter.newLine();
                        }
                    }
                }
            }
            catch (IOException e) {
                e.printStackTrace();
                return false;
            }
            finally {
                try {
                    if (bufferedWriter != null)
                        bufferedWriter.close();
                    
                    if (fileWriter != null)
                        fileWriter.close();
                    
                }
                catch (IOException ex) {
                    ex.printStackTrace();
                    return false;
                }
            }
        }
        
        System.out.println("Finished writing VOC results");
        return true;
    }
    
}