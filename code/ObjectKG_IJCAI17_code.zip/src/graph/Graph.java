package graph;


import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Graph<T> {

	protected Map<T, Node<T>> nodes;
		
	public int numNodes() {
		return nodes.size();
	}
	
	public int computeNumEdges() {
		int count = 0;
		for (Node<T> n : getNodes())
			count += n.nb.size();
		return count;
	}
	
	public <E> boolean containsNb(List<Edge<E>> nb, Node<E> n) {
		for (Edge<E> e : nb)
			if (e.otherEnd == n)
				return true;
		
		return false;
	}
	
	public void addNode(Node<T> n) {
		nodes.put(n.getKey(), n);
	}
	
	public Graph() {
		nodes = new HashMap<T, Node<T>>();
	}
	
	
	public Node<T> getNode(T key) {
		return nodes.get(key);
	}
	
	public Collection<T> getKeys() {
		return Collections.unmodifiableCollection(nodes.keySet());
	}
	
	public Collection<Node<T>> getNodes() {
		return Collections.unmodifiableCollection(nodes.values());
	}
	
		
}
