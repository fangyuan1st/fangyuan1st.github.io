package graph;

import java.util.ArrayList;
import java.util.List;



public class Node<T> {
	
	private T key;
	private String label;
	
	public List<Edge<T>> nb;
	public Object attachment;
	
		
	public void setLabel(String l) {
		this.label = l;
	}
	
	public String getLabel() {
		return label;
	}
	
	public Node(T key) {
		this.key = key;
		nb = new ArrayList<Edge<T>>();
		
	}
	
	
	public T getKey() {
		return key;
	}

	
}
