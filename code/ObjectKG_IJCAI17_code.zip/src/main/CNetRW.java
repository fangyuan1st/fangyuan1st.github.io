package main;


import java.util.Map;
import java.util.Set;

import cnet.CNet;
import gnu.trove.map.hash.THashMap;
import gnu.trove.set.hash.THashSet;
import utils.Args;
import utils.TextReader;
import utils.TextWriter;

public class CNetRW {
	
	private static void incMap(Map<Integer, Double> map, int key, double inc) {
		if (map.containsKey(key))
			map.put(key, map.get(key) + inc);
		else
			map.put(key, inc);
	}
	
	public static void main(String[] args) throws Exception {
		double alpha = Args.extractDouble(args, "alpha", 0.15);
		
		System.out.println("loading CNet graph...");
		CNet cnet = new CNet();
		cnet.load("C:\\fangyuan\\cnet\\conceptnet-assertions-5.5.0-en-clean.gexf");
		System.out.println("Loaded " + cnet.numNodes() + " nodes, " + cnet.computeNumEdges() + " edges...");
		
		TextReader in = new TextReader("C:\\fangyuan\\cnet\\mapping.csv");
		in.readln(); // ignore header
		String line;
		Map<Integer, Set<String>> coco2cnet = new THashMap<Integer, Set<String>>();
		Map<String, Integer> cnet2coco = new THashMap<String, Integer>();
		while ( (line = in.readln()) != null) {
			String[] parts = line.split(",");
			int cocoId = Integer.parseInt(parts[1]);
			String[] cnetIds = parts[3].split(":");
			for (String cnetId : cnetIds)
				cnet2coco.put(cnetId, cocoId);
			
			Set<String> cnetIdSet = new THashSet<String>();
			for (String cnetId : cnetIds)
				cnetIdSet.add(cnetId);
			coco2cnet.put(cocoId, cnetIdSet);
		}
		in.close();
		
		TextWriter out = new TextWriter("C:\\fangyuan\\io\\input\\rw_prob");
		for (int cocoSeed : coco2cnet.keySet()) {
			System.out.println("Doing random walk " + cocoSeed + "...");
			Set<String> seeds = coco2cnet.get(cocoSeed);
			Map<String, Double> result = cnet.computeRW(alpha, seeds);
			Map<Integer, Double> cocoResult = new THashMap<Integer, Double>();
			for (String cnetId : cnet2coco.keySet()) {
				int cocoId = cnet2coco.get(cnetId);
				double value = result.get(cnetId);
				incMap(cocoResult, cocoId, value);
			}
			for (int cocoId : cocoResult.keySet()) {
				out.writeln(cocoSeed + "\t" + cocoId + "\t" + cocoResult.get(cocoId));
			}
		}
		
		out.close();
		
		
	}

}
