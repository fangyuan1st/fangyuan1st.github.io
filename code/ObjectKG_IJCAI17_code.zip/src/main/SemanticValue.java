package main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import utils.Args;

public class SemanticValue {
	
	public static void main(String[] args) throws Exception {
		String mode = Args.extractString(args, "mode", "cnet");
		String dataset = Args.extractString(args, "dataset", "coco");
		String fcat = Args.extractString(args, "fcat", "input/category_ids_" + dataset + ".csv");
		String fmat = Args.extractString(args, "fmat", "input/matrix_" + mode);
		
		SimMatrix simMatrix = new SimMatrix(fcat);
		simMatrix.load(fmat);
		
		
		List<Double> s = new ArrayList<Double>();
		for (int cat1 : simMatrix.getCategoryIds())
			for (int cat2 : simMatrix.getCategoryIds())
				if (cat1 <= cat2)
					s.add(simMatrix.getSimilarity(cat1, cat2));
		Collections.sort(s);
		System.out.println("median = " + s.get( (int)((80 * 79 / 2 + 80) * 0.5 )) );
		// keyboard =76, mouse=74, laptop=73, tv=72
		System.out.println("keybords");
		System.out.println(simMatrix.getSimilarity(76, 74));
		System.out.println(simMatrix.getSimilarity(76, 73));
		System.out.println(simMatrix.getSimilarity(76, 72));
		// person = 1 , surfboard=42
		System.out.println("person");
		System.out.println(simMatrix.getSimilarity(1, 42));
		
	}
	
}
