package main;

import gnu.trove.map.hash.THashMap;
import gnu.trove.set.hash.THashSet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import coco.CocoAnnotation;
import coco.Groundtruths;
import coco.ImageGroundtruth;
import utils.TextReader;
import utils.TextWriter;


public class SimMatrix {
	
	public static final int MAX_CAT_ID = 100;
	private double[][] matrix;
	private Set<Integer> catSet;
	private int[][] msc;
	
	
	public void updateMSC(int ncat) {
		Map<Integer, List<Integer>> map = new THashMap<Integer, List<Integer>>();
		for (final int cat : this.getCategoryIds()) {
			List<Integer> l = new ArrayList<Integer>();
			for (int cat2 : this.getCategoryIds()) { 
				double w = this.getSimilarity(cat, cat2);
				if (w > 0)
					l.add(cat2);
			}
			Collections.sort(l, new Comparator<Integer>() {
				@Override
				public int compare(Integer arg0, Integer arg1) {
					return - Double.compare(getSimilarity(cat, arg0), getSimilarity(cat, arg1));
				}} );
			int size = Math.min(l.size(), ncat);
			l.subList(size, l.size()).clear();
			map.put(cat, l);
		}		
		
		// make matrix truely KNN (a neighbor is added if its the KNN in either direction)
		for (int cat : map.keySet()) {
			for (int cat2 :  map.get(cat)) {
				if (cat != cat2 && !map.get(cat2).contains(cat))
					map.get(cat2).add(cat);
			}
		}
		
		// convert list and array for faster program
		msc = new int[MAX_CAT_ID][];
		for (int cat : map.keySet()) {
			List<Integer> l = map.get(cat);
			msc[cat] = new int[l.size()];
			for (int i = 0; i < l.size(); i++)
				msc[cat][i] = l.get(i);
		}
				
	}
	
	public int[] getMSC(int catId) {
		return msc[catId];
	}
	
	
	public SimMatrix(String catFile) throws Exception {
		matrix = new double[MAX_CAT_ID][MAX_CAT_ID];
		for (int i = 0; i < MAX_CAT_ID; i++)
			Arrays.fill(matrix[i], 0);
		
		catSet = new THashSet<Integer>();
		TextReader in = new TextReader(catFile);
		String[] parts = in.readln().split(",");
		for (int i = 0; i < parts.length; i++)
			catSet.add(Integer.valueOf(parts[i]));			
		in.close();
	}
	
	public SimMatrix(String catFile, Random rnd) throws Exception {
		this(catFile);
		
		for (int cat1 : catSet)
			for (int cat2 : catSet)
				if (cat1 <= cat2) {
					double s = rnd.nextDouble();
					matrix[cat1][cat2] = s;
					matrix[cat2][cat1] = s;
				}
		
	}
	
	
	public SimMatrix(String rwFile, String catFile) throws Exception {
		this(catFile);
		
		double[][] rw = new double[MAX_CAT_ID][MAX_CAT_ID];
		for (int i = 0; i < MAX_CAT_ID; i++)
			Arrays.fill(rw[i], 0);
				
		TextReader in = new TextReader(rwFile);
		String line;
		while ( (line = in.readln()) != null ) {
			String[] parts = line.split("\t");
			int cat1 = Integer.parseInt(parts[0]);
			int cat2 = Integer.parseInt(parts[1]);
			double p = Double.parseDouble(parts[2]);
			rw[cat1][cat2] = p;
		}
		
		for (int cat1 : catSet)
			for (int cat2 : catSet)
					matrix[cat1][cat2] = Math.sqrt(rw[cat1][cat2] * rw[cat2][cat1]);
	}
	
	public SimMatrix(String catFile, Groundtruths gt1, Groundtruths gt2, Random rnd, int k) throws Exception {
		this(catFile);
		
		double[] freq = new double[MAX_CAT_ID];
		Arrays.fill(freq, 0);
		List<ImageGroundtruth> l1 = new ArrayList<ImageGroundtruth>(gt1.imageMap.values());
		List<ImageGroundtruth> l2 = new ArrayList<ImageGroundtruth>(gt2.imageMap.values());
		Collections.shuffle(l1, rnd);
		Collections.shuffle(l2, rnd);
		if (k < l1.size())
			l1.subList(k, l1.size()).clear();
		if (k < l2.size())
			l2.subList(k, l2.size()).clear();
		
		List<ImageGroundtruth> l = new ArrayList<ImageGroundtruth>();
		l.addAll(l1);
		l.addAll(l2);
		
		for (ImageGroundtruth imgGt : l) {
			int[] imgCat = new int[MAX_CAT_ID];
			Arrays.fill(imgCat, 0);
			for (CocoAnnotation a : imgGt.annotations) 
				imgCat[a.categoryId] ++;
			
			for (int catId : catSet)
				if (imgCat[catId] > 0)
					freq[catId] ++;
				
			for (int cat1 : catSet)
				for (int cat2 : catSet)
					if (cat1 != cat2) {
						if (imgCat[cat1] > 0 && imgCat[cat2] > 0)
							matrix[cat1][cat2] ++;
					}
					else {  //cat1 == cat2
						if (imgCat[cat1] > 1)
							matrix[cat1][cat1] ++;
					}
		}
		
		double n = l.size();
		for (int cat1 : catSet)
			for (int cat2 : catSet) {
					double xy = matrix[cat1][cat2];
					double x = freq[cat1];
					double y = freq[cat2];
					if (xy > 0)
						//matrix[cat1][cat2] = xy / (x + y - xy);
						matrix[cat1][cat2] = Math.max(Math.log((xy * n / (x * y))), 0);
				}
	}
	
	
	
	
	
	
	public Set<Integer> getCategoryIds() {
		return Collections.unmodifiableSet(catSet);
	}
	
	public double getSimilarity(int cat1, int cat2) {
		return matrix[cat1][cat2];
	}
	
	
	public void load(String matFile) throws Exception {
		TextReader in = new TextReader(matFile);
		String line;
		while ( (line = in.readln()) != null) {
			String[] split = line.split("\t");
			int cat1 = Integer.parseInt(split[0]);
			int cat2 = Integer.parseInt(split[1]);
			double sim = Double.parseDouble(split[2]);
			matrix[cat1][cat2] = sim;
		}
		in.close();
	}
	
	public void save(String matFile) throws Exception {
		TextWriter out = new TextWriter(matFile);
		for (int cat1 : catSet)
			for (int cat2 : catSet) 
				out.writeln(cat1 + "\t" + cat2 + "\t" + matrix[cat1][cat2]);
		out.close();
	}
}
