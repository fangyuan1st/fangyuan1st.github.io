package utils;

public class Comm {

	public static void quit(String msg) {
		System.err.println(msg);
		System.exit(0);
	}
}
